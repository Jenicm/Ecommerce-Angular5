export class Contacto {
    _id: string;
    mail: string;
    comentario: string;
    fecha: Date;
  }