export class Insertar {
    _id : number;
    titulo: string;
    descripcion : string;
    foto : string;
    precio : string;
}
