export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyC8R6cC402aYKm8d5j9HqaQu_VWMtQon_s",
    authDomain: "geotracker-a85a0.firebaseapp.com",
    databaseURL: "https://geotracker-a85a0.firebaseio.com",
    projectId: "geotracker-a85a0",
    storageBucket: "geotracker-a85a0.appspot.com",
    messagingSenderId: "937114079885"
  }
};
