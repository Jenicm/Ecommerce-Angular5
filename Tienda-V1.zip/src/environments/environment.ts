export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyA-SPAweUYR1On647sI2BhTog_xTB2vySk",
    authDomain: "tienda-5f83a.firebaseapp.com",
    databaseURL: "https://tienda-5f83a.firebaseio.com",
    projectId: "tienda-5f83a",
    storageBucket: "",
    messagingSenderId: "1028009669020"
  }
};
